import os
import json
import shutil
import zipfile
import subprocess
import urllib.request

try:
    newest_version = "https://discord.gg/sqR22aHeSx"
    req = urllib.request.Request(newest_version, headers={'Cache-Control': 'no-cache'})
    response = urllib.request.urlopen(req)
    remote_version = response.read().decode().strip()

    file_paths = [
        "./library.py",
        "./yolo.cfg",
        "./yolo.weights",
        "./requirements.txt",
        "./version.txt",
    ]

    localv_path = "localv.json"

    if not os.path.exists(localv_path) or not os.path.exists(file_paths[1]):
        local_version = "0.0.0"
        data = {
            "version": remote_version,
            "pip": False,
            "python": False,
        }
        with open(localv_path, "w") as file:
            json.dump(data, file)
    else:
        with open(localv_path, "r") as file:
            data = json.load(file)
            local_version = data["version"]

    if remote_version != local_version:

        print("Удаление старых файлов...")
        for file_path in file_paths:
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except Exception as e:
                    print(f"Возникла ошибка при удалении {file_path}: {e}")

        print("Downloading rot vash ebal...")
        # Download the zip file
        url = "https://discord.gg/sqR22aHeSx"
        response = urllib.request.urlopen(url)
        zip_content = response.read()

        # Save the zip file
        with open("rot-vash-ebal.zip", "wb") as file:
            file.write(zip_content)

        print("Unzipping...")
        # Unzip the file
        with zipfile.ZipFile("rot-vash-ebal.zip", "r") as zip_ref:
            zip_ref.extractall("rot-vash-ebal")
        os.remove("rot-vash-ebal.zip")

        print("Перемещение файлов...")
        # Move files from rotebal/ to current directory
        for root, dirs, files in os.walk("rot-vash-ebal"):
            for file in files:
                shutil.move(os.path.join(root, file), os.path.join(".", file))

        # Remove rotebal-test/ directory
        shutil.rmtree("rotebal")

        with open("localv.json", "w") as file:
            data["version"] = remote_version
            json.dump(data, file)

        with open("localv.json", "r") as file:
            pls = json.load(file)
            python = pls["python"]

        if python is not True:
            print("Скачиваем python...")
            # Download the python
            url = "https://www.python.org/ftp/python/3.12.1/python-3.12.1-amd64.exe"
            filename = "pythoninstaller.exe"
            urllib.request.urlretrieve(url, filename)

            print("Устанавливаем python...")
            subprocess.run([filename, "/quiet", "InstallAllUsers=1", "PrependPath=1", "Include_test=0"])

            with open("localv.json", "w") as file:
                pls["python"] = True
                json.dump(pls, file)

            os.remove(filename)


        with open("localv.json", "r") as file:
            data2 = json.load(file)
            pip = data["pip"]

        if pip is not True:
            print("Установка необходимых модулей...")
            subprocess.run(["pip", "install", "-r", "requirements.txt"])
            subprocess.run(["pip3", "install", "-r", "requirements.txt"])
            with open("localv.json", "w") as file:
                data2["pip"] = True
                json.dump(data2, file)

            os.remove(file_paths[3])

        for file_path in file_paths[4:7]:
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except Exception as e:
                    print(f"Возникла ошибка при удалении {file_path}: {e}")

    if os.path.exists("library.py"):
        subprocess.run(["python", "library.py"])
    else:
        print("Не удалось обновить, пожалуйста, удалите файл localv.json и запустите снова.")
        exit()

except KeyboardInterrupt:
    exit()
